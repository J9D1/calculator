import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Введите выражение, например 10+5:");
        String input = scanner.nextLine();

          try {
            String result = calc(input);
            System.out.println("Результат: " + result);
        } catch (Exception e) {
            System.out.println("Ошибка: " + e.getMessage());
            }
        }

    public static String calc(String input) {
        input = input.replaceAll("\\s+", "");

        int operatorCount = 0;
        for (int i = 0; i < input.length(); i++) {
            char ch = input.charAt(i);
            if ((ch == '+' || ch == '-' || ch == '*' || ch == '/') && i != 0) {
                operatorCount++;
            }
        }

        if (operatorCount != 1) {
            throw new IllegalArgumentException("Неверный формат арифметической операции");
        }

        int operatorIndex = -1;
        char operator = 0;

        for (int i = 1; i < input.length(); i++) { // начинаем с 1, чтобы избежать унарного минуса
            char ch = input.charAt(i);
            if (ch == '+' || ch == '-' || ch == '*' || ch == '/') {
                operator = ch;
                operatorIndex = i;
                break;
            }
        }

        if (operatorIndex == -1) {
            throw new IllegalArgumentException("Строка не является математической операцией");
        }

        String left = input.substring(0, operatorIndex);
        String right = input.substring(operatorIndex + 1);

        if (left.isEmpty() || right.isEmpty()) {
            throw new IllegalArgumentException("Неверный формат операции");
        }

        if (left.contains(".") || left.contains(",") || right.contains(".") || right.contains(",")) {
            throw new IllegalArgumentException("Используются только целые числа!");
        }

        int a = Integer.parseInt(left);
        int b = Integer.parseInt(right);

        if (a < -10 || a > 10 || b < -10 || b > 10) {
            throw new IllegalArgumentException("Числа должны быть от 1 до 10");
        }

        int result;
        switch (operator) {
            case '+': result = a + b; break;
            case '-': result = a - b; break;
            case '*': result = a * b; break;
            case '/': result = a / b; break;
            default:
                throw new IllegalArgumentException("Неверный оператор");
        }

        return String.valueOf(result);
    }
}